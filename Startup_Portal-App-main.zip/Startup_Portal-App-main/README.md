# portal_app

Passionate about empowering startups and social causes through innovative technology.

I have Created a portal app that serves as a vibrant social media platform for startups, providing them with a unique space to connect, share ideas, and secure funding.

Key features:
Dedicated pitches for startups to attract potential investors
Seamless interface for investors to review and evaluate startups
Integrated NGO section to facilitate funding for social initiatives

Technical :

Proficient in Flutter, a cross-platform app development framework
> Used Firebase for backend and authentication. 
> Firebase Storage to store the local image from the user end and send it to the Database. 
> For data analysis and creating Graphical representation I have used the "f1_chart" package. 
> and many other useful packages like 
    image picker, flutter svg, google fonts etc. 

The following app is just the prototype of a wide range idea.

happy developemnt :)
