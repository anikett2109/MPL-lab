class AppIcons {
  static const String home = 'assets/svg/ic_home.svg';
  static const String location = 'assets/svg/ic_location.svg';
  static const String message = 'assets/svg/ic_messages.svg';
  static const String user = 'assets/svg/ic_user.svg';
  static const String add = 'assets/svg/ic_add.svg';
  static const String favorite = 'assets/svg/ic_favorite.svg';
}