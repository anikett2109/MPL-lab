// import 'package:flutter/material.dart';

// class DetailInvestorPage extends StatelessWidget {
//   const DetailInvestorPage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Column(
//         children: [

//         ],
//       ),
//     );
//   }
// }