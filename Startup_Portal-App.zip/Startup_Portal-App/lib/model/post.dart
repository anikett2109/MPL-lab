class Post {
  final int userid;
  final String username;
  final String title;
  final String discription;
  final String usercompany;
  final String image;
  

  Post({
    required this.userid,
    required this.username,
    required this.title,
    required this.discription,
    required this.usercompany,
    required this.image,
    
  });
}
